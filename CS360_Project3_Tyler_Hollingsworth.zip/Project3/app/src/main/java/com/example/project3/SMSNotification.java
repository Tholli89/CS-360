package com.example.project3;

import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;

public class SMSNotification {

    public static AlertDialog doubleButton(final Items context){
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle(R.string.ad_sms_title)
                .setCancelable(false)
                .setMessage(R.string.ad_sms_msg)
                .setPositiveButton(R.string.ad_sms_enable_button, (dialog, arg1) -> {
                    Toast.makeText(context, "SMS Alerts Enable", Toast.LENGTH_LONG).show();
                    Items.AllowSendSMS();
                    dialog.cancel();
                })
                .setNegativeButton(R.string.ad_sms_disable_button, (dialog, arg1) -> {
                    Toast.makeText(context, "SMS Alerts Disable", Toast.LENGTH_LONG).show();
                    Items.DenySendSMS();
                    dialog.cancel();
                });

        return builder.create();
    }
}
