package com.example.project3;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;

public class Items extends AppCompatActivity {

    TextView UserName, TotalItems;
    Button AddItemButton, SmsButton, DelAllItemsButton;
    ListView ItemsListView;
    ItemsSQLiteHandler db;
    static String NameHolder, EmailHolder, PhoneNumHolder;
    AlertDialog AlertDialog = null;
    ArrayList<Item> items;
    CustomItemsList customItemsList;
    int itemsCount;

    public static final String UserEmail = "";
    private static final int USER_PERMISSIONS_REQUEST_SEND_SMS = 0;
    private static boolean smsAuthorized = false;
    private static boolean deleteItems = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_items);

        UserName = findViewById(R.id.textViewUserNameLabel);
        TotalItems = findViewById(R.id.textViewTotalItemsCount);
        AddItemButton = findViewById(R.id.addItemButton);
        SmsButton = findViewById(R.id.smsNotification);
        DelAllItemsButton = findViewById(R.id.deleteAllItemsButton);
        ItemsListView = findViewById(R.id.bodyListView);
        db = new ItemsSQLiteHandler(this);

        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            NameHolder = bundle.getString("user_name");
            EmailHolder = bundle.getString("user_email");
            PhoneNumHolder = bundle.getString("user_phone");
            UserName.setText(getString(R.string.salutation, NameHolder.toUpperCase()));
        }

        items = (ArrayList<Item>) db.getAllItems();

        itemsCount = db.getItemsCount();

        if (itemsCount > 0) {
            customItemsList = new CustomItemsList(this, items, db);
            ItemsListView.setAdapter(customItemsList);
        } else {
            Toast.makeText(this, "Database is Empty", Toast.LENGTH_LONG).show();
        }

        TotalItems.setText(String.valueOf(itemsCount));

        AddItemButton.setOnClickListener(view -> {

            Intent add = new Intent(this, AddItem.class);
            add.putExtra(UserEmail, EmailHolder);
            startActivityForResult(add, 1);
        });

        SmsButton.setOnClickListener(view -> {
            if (ContextCompat.checkSelfPermission(this,
                    Manifest.permission.SEND_SMS)
                    != PackageManager.PERMISSION_GRANTED) {

                if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                        Manifest.permission.SEND_SMS)) {
                    Toast.makeText(this,"Device SMS Permission is Needed", Toast.LENGTH_LONG).show();
                } else {
                    ActivityCompat.requestPermissions(this,
                            new String[] {Manifest.permission.SEND_SMS},
                            USER_PERMISSIONS_REQUEST_SEND_SMS);
                }
            } else {
                Toast.makeText(this,"Device SMS Permission is Allowed", Toast.LENGTH_LONG).show();
            }
            AlertDialog = SMSNotification.doubleButton(this);
            AlertDialog.show();
        });

        DelAllItemsButton.setOnClickListener(view -> {
            itemsCount = db.getItemsCount();

            if (itemsCount > 0) {
                AlertDialog = DeleteItems.doubleButton(this);
                AlertDialog.show();

                AlertDialog.setCancelable(true);
                AlertDialog.setOnCancelListener(dialog -> DeleteAllItems());
            } else {
                Toast.makeText(this, "Database is Empty", Toast.LENGTH_LONG).show();
            }
        });
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1) {
            if (resultCode == RESULT_OK) {
                itemsCount = db.getItemsCount();
                TotalItems.setText(String.valueOf(itemsCount));

                if(customItemsList == null)	{
                    customItemsList = new CustomItemsList(this, items, db);
                    ItemsListView.setAdapter(customItemsList);
                }

                customItemsList.items = (ArrayList<Item>) db.getAllItems();
                ((BaseAdapter)ItemsListView.getAdapter()).notifyDataSetChanged();
            } else {
                Toast.makeText(this, "Action Canceled", Toast.LENGTH_SHORT).show();
            }
        }
    }

    public static void YesDeleteItems() {
        deleteItems = true;
    }

    public static void NoDeleteItems() {
        deleteItems = false;
    }

    public void DeleteAllItems() {
        if (deleteItems) {
            db.deleteAllItems();
            Toast.makeText(this, "All Items were Deleted", Toast.LENGTH_SHORT).show();
            TotalItems.setText("0");

            if (customItemsList == null) {
                customItemsList = new CustomItemsList(this, items, db);
                ItemsListView.setAdapter(customItemsList);
            }

            customItemsList.items = (ArrayList<Item>) db.getAllItems();
            ((BaseAdapter) ItemsListView.getAdapter()).notifyDataSetChanged();
        }
    }

    public static void AllowSendSMS() {
        smsAuthorized = true;
    }

    public static void DenySendSMS() {
        smsAuthorized = false;
    }

    public static void SendSMSMessage(Context context) {
        String phoneNo = PhoneNumHolder;
        String smsMsg = "Please, you have items with zero value in your Inventory App.";

        if (smsAuthorized) {
            try {
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(phoneNo, null, smsMsg, null, null);
                Toast.makeText(context, "SMS Sent", Toast.LENGTH_LONG).show();
            } catch (Exception ex) {
                Toast.makeText(context, "Device Permission Denied", Toast.LENGTH_LONG).show();
                ex.printStackTrace();
            }
        } else {
            Toast.makeText(context, "App SMS Alert Disable", Toast.LENGTH_LONG).show();
        }
    }
}
