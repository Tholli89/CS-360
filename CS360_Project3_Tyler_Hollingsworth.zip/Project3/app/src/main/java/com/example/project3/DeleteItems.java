package com.example.project3;

import androidx.appcompat.app.AlertDialog;

public class DeleteItems {

    public static AlertDialog doubleButton(final Items context){
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle(R.string.ad_delete_title)
                .setCancelable(false)
                .setMessage(R.string.ad_delete_msg)
                .setPositiveButton(R.string.ad_delete_dialog_yes_button, (dialog, arg1) -> {
                    Items.YesDeleteItems();
                    dialog.cancel();
                })
                .setNegativeButton(R.string.ad_delete_dialog_no_button, (dialog, arg1) -> {
                    Items.NoDeleteItems();
                    dialog.cancel();
                });

        return builder.create();
    }
}
